<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Email</title>
</head>
<body>
	<h4> {{$customer_email}} </h4>
	<h4> {{$customer_name}} </h4>
 
	<h4>Verify Code 
	 {{$code}} </h4>
 
</body>
</html>