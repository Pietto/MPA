  
  <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>Update Profile || <?php echo e($images->website_title); ?> || mitfarm</title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section id="form"><!--form-->
		<div class="container">
			<div class="row">

<div class="col-sm-6 col-sm-offset-3" data-aos="fade-right" data-aos-duration="1000">
	<div class="signup-form"><!--sign up form-->

		<?php 
         $massage = Session::get('massage');
         
         if($massage){  ?>
          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
          <?php   Session::put('massage',NULL); } ?> 

		<h2>Update Your Profile</h2>
		<form action="<?php echo e(URL('Update-Page-Profile-Mitfarm')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

	<input type="text" value="<?php echo e($updateprofile->customer_name); ?> " name="customer_name"  />

    <input type="phone" value="<?php echo e($updateprofile->customer_phone); ?>" name="customer_phone"  />

	<input type="city" value="<?php echo e($updateprofile->customer_city); ?>" name="customer_city"  />

			<button type="submit" class="btn btn-default">Update Profile</button>

		</form>
	</div><!--/sign up form-->
</div> 

</div>
		</div>
	</section>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>