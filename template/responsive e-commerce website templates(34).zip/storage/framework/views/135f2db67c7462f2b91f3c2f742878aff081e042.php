<?php $__env->startSection('main_body'); ?>
  <div class="inner-block">

     <div class="market-updates text-center">

<div class="container">
<div class="col-md-5">
    <div class="form-area">
        <form role="form" method="post" action="<?php echo e(URL('updatemamber', $edit_Member->member_id)); ?>" enctype="multipart/form-data" >

            <?php echo e(csrf_field()); ?>

        <br style="clear:both">
        <h3 style="margin-bottom: 25px; text-align: center;">Edit Team Member</h3>
       <?php
         $massage = Session::get('massage');

         if($massage){  ?>
          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
          <?php   Session::put('massage',NULL); } ?>

        <label style="text-align:left;width:100%;">Team Member Name</label>
        <div class="form-group">
           <input type="text" value="<?php echo e($edit_Member->member_name); ?>" class="form-control" id="name" name="member_name"  required>
        </div>




        <label style="text-align:left;width:100%;">Member Image</label>
        <div class="form-group">
          <img src="<?php echo e(URL($edit_Member->member_image)); ?>" height="150px;" width="150px;" alt="">
           <input type="file" class="form-control" id="name" name="member_image"   >
        </div>

         <label style="text-align:left;width:100%;">Member  Description</label>
        <div class="form-group">
        <textarea class="form-control" name="member_detels" type="textarea" id="message" placeholder="Enter Member  Description"   rows="7"><?php echo e($edit_Member->member_detels); ?></textarea>
        </div>

        <label style="text-align:left;width:100%;">Member Post</label>
        <div class="form-group">
            <select  class="form-control" name="member_type"  >
              <?php if($edit_Member->member_type==1): ?>
              <option selected='selected' value="1">MD</option>
              <option value="2">CO</option>
              <option value="3">Manager</option>
              <option value="4">Share Holder</option>
              <option value="5">General Mamber </option>
               <?php elseif($edit_Member->member_type==2): ?>
               <option value="1">MD</option>
               <option selected='selected' value="2">CO</option>
               <option value="3">Manager</option>
               <option value="4">Share Holder</option>
               <option value="5">General Mamber </option>
               <?php elseif($edit_Member->member_type==3): ?>
               <option value="1">MD</option>
               <option value="2">CO</option>
               <option selected='selected' value="3">Manager</option>
               <option value="4">Share Holder</option>
               <option value="5">General Mamber </option>
               <?php elseif($edit_Member->member_type==4): ?>
               <option value="1">MD</option>
               <option value="2">CO</option>
               <option value="3">Manager</option>
               <option selected='selected' value="4">Share Holder</option>
               <option value="5">General Mamber </option>
               <?php elseif($edit_Member->member_type==5): ?>
               <option value="1">MD</option>
               <option value="2">CO</option>
               <option value="3">Manager</option>
               <option value="4">Share Holder</option>
               <option selected='selected' value="5">General Mamber </option>
               <?php endif; ?>

          </select>
        </div>







       <input type="submit"  name="submit" value="Update Team Member" class="btn btn-primary pull-right" />
        </form>
    </div>
</div>
</div>

  </div>
</div>
 <div class="inner-block">
 <div class="market-updates text-center">
    </div>
</div> <div class="inner-block">
 <div class="market-updates text-center">
    </div>
</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('backsite/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>