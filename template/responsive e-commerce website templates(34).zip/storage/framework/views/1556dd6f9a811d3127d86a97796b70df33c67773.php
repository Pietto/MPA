  
<?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>add to cart || <?php echo e($images->website_title); ?> || mitfarm </title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


<table>
	<thead>
	<tr>
		<th>SL</th>
		<th>Product Name</th>
		<th>Product Image</th>
		<th>Product Price</th>
		<th>Quntity</th>
		<th>Total</th>
		<th>Action</th>
	</tr>
	</thead>
	<tbody>
<?php 


   $content = Cart::content();

 

    $i=0;
   foreach ($content as $v_content) {
    $i++;
?>		
	<tr>
		<td><?php echo e($i); ?> </td>
		<td><?php echo e($v_content->name); ?> </td>
		<td> <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($v_content->options->image)); ?>" height="70px;" width="70px;" alt=""> </td>
		<td><?php echo e($v_content->price); ?> tk</td> 
		<td>
          <form action="<?php echo e(route('Update-Cart-mitfarm',$v_content->rowId)); ?> " method="post">
          	<?php echo e(csrf_field()); ?>

          	<input style="width:50px;" type="text" name="qty" value="<?php echo e($v_content->qty); ?>">
          	<input type="submit" value="Update">
          </form>
			 </td> 
		<td><?php echo e($v_content->total); ?> tk</td>
		<td><a onclick="return confirm('ARE YOU SURE TO DELET');" href="<?php echo e(URL('Delete-Cart-mitfarm/'.$v_content->rowId)); ?> "> Delete </a></td>
	</tr>

<?php } ?>	 

	</tbody>
</table>


 
<div class="cart_site">

	<div class="main">
		<div class="cart"> 
		      <p>Sub Total Price : <?php echo e(Cart::subtotal()); ?> tk</p>
		 </div> 
		 <div class="cart"> 
		      <p>Text  : Free</p>
		 </div> 
		 <div class="cart"> 
		      <p>Total Price: <?php echo e(Cart::total()); ?> tk</p>
		 </div>     
	</div>
 
 </div>	 
 
 		
	 

  
 
 
 <div class="full_sexcen">
 	
 	<div class="sexcen">
 		<div class="rightsite">
 			<?php 
                  $customer = Session::get('customer_id');

                  
                ?>    
                 
          <?php if($customer): ?>
 		<a href="<?php echo e(route('Payment-Page-mitfarm')); ?>"> <h5 data-aos="slide-up" data-aos-duration="1000"> Check Out</h5> </a>
 		  <?php else: ?>
 		  <a href="<?php echo e(route('Login-Page-mitfarm')); ?>"> <h5 data-aos="slide-up" data-aos-duration="1000"> Check Out</h5> </a>
 		  <?php endif; ?>
 		</div>
 		<div class="leftsite">

 		<a href="<?php echo e(route('Show-All-Products-mitfarm')); ?> ">	<h5 data-aos="fade-right" data-aos-duration="1000"> Continue Shoping  </h5></a>
 		</div>
 	</div>
 </div>








 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>