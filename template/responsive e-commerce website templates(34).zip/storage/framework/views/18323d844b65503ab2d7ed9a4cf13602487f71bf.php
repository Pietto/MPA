<?php $__env->startSection('main_body'); ?>

<!--inner block start here-->
 <img src="<?php echo e(asset('fontpage/assets/img/mitlogo2.png')); ?>" width="100%;" height="100%;" alt="">
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backsite/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>