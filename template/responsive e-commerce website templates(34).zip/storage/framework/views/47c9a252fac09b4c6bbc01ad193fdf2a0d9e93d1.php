  

    <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title> <?php echo e($images->website_title); ?> </title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section id="form"><!--form-->
		<div class="container">
			<div class="row">

<div class="col-sm-6 col-sm-offset-3" data-aos="fade-right" data-aos-duration="1000">
	<div class="signup-form"><!--sign up form-->

		<?php 
         $massage = Session::get('massage');
         
         if($massage){  ?>
          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
          <?php   Session::put('massage',NULL); } ?> 

		<h2>New User Signup!</h2>
		<form action="<?php echo e(URL('Registration-Page-Mitfarm')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

			<input type="text" placeholder="Enter Name" name="customer_name"  />

			<input type="email" placeholder="Email Address" name="customer_email"  />


			<input type="phone" placeholder="Enter Phone" name="customer_phone"  />

			<input type="city" placeholder="Enter city" name="customer_city"  />

			<button type="submit" class="btn btn-default">Signup</button>

		</form>
	</div><!--/sign up form-->
</div> 

</div>
		</div>
	</section>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>