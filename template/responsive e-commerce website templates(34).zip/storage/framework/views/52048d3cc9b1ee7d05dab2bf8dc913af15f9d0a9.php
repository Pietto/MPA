<?php $__env->startSection('main_body'); ?>
<?php
     $image = DB::table('seo')->where('website_id' ,'1')->first(); ?>
<!--inner block start here-->
 <img src="<?php echo e(url($image->website_image)); ?>" width="100%;" height="100%;" alt="">
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backsite/master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>