  

   <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>payment page || <?php echo e($images->website_title); ?> || mitfarm</title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


<section id="form"><!--form-->
		<div class="container">
			<div class="row">	
				
				<div class="col-sm-12">
					<div class="signup-form"><!--sign up form-->
						<h2>You Shoping Product</h2>
						
						<?php 
         $massage = Session::get('massage');
         
         if($massage){  ?>
          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
          <?php   Session::put('massage',NULL); } ?> 

						<table>
	<thead>
	<tr>
		<th>SL</th>
		<th>Product Name</th>
		<th>Product Image</th>
		<th>Product Price</th>
		<th>Quntity</th>
		<th>Total</th>
		 
	</tr>
	</thead>
	<tbody>
<?php 


   $content = Cart::content();

 

    $i=0;
   foreach ($content as $v_content) {
    $i++;
?>		
	<tr>
		<td><?php echo e($i); ?> </td>
		<td><?php echo e($v_content->name); ?> </td>
		<td> <img src="<?php echo e(URL($v_content->options->image)); ?>" height="70px;" width="70px;" alt=""> </td>
		<td><?php echo e($v_content->price); ?> tk </td> 
		<td><?php echo e($v_content->qty); ?> </td> 
		<td><?php echo e($v_content->total); ?> tk </td>
		 
	</tr>
<?php } ?>
  

	 

	</tbody>
</table>

<div class="cart_site">

	<div class="main">
		<div class="cart"> 
		      <p>Total Amound: <?php echo e(Cart::total()); ?> tk</p>
		 </div> 
		     
	</div>
 
 </div>	 

<style>
	
	.payment ul li {
         float:left;
         margin:0 auto;
         margin:15px;
         color:#D08D25;
         text-align:center;

	}
	.payment h4{
		color:#D08D25;
	}
	#form{
		margin-top: 20px;
	}
</style>
		
					</div><!--/sign up form-->
				</div>
			</div>
			<div class="payment">
				
	<ul>
		 
 
<a href="<?php echo e(URL('Order-Page-mitfarm')); ?>"> <li> <img src="<?php echo e(asset('fontpage/css/mamber/assets/img/download (1).jpg')); ?> "  width="250px;" height="150px;" alt=""><br> <h4>Hand Cash</h4>  </li>  </a>




  

	</ul>
			</div>
		</div>
	</section>

	 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>