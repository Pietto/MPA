  
  
    <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title> <?php echo e($images->website_title); ?> </title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>


<section id="form"><!--form-->
		<div class="container">
			<div class="row">	
			<div class="col-sm-10" >	

		<?php $name = Session::get('customer_name'); ?>		 
						 
						 
		 <h3 class="succ"> Thank You <spam style="color:#D08D25" ><?php echo $name; ?></spam>  . Your Order Is Successfull .Your Product is delevery After 12 Horus .Your Delevary As Any Problam Pls <a style="color:#D08D25" href="<?php echo e(route('Contick-Page-mitfarm')); ?> "> Contick Our</a> . <br>
                  <a style="color:#D08D25"  href="<?php echo e(route('Customer-Profile-mitfarm')); ?> ">Your Order Detels</a>  </h3>
				 
			 
			 
		 
 
		</div>
		</div>
		</div>
	</section>

	 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>