<!DOCTYPE HTML>
<html lang="en-US">
 
<head>
    <?php echo $__env->yieldContent('title'); ?>
    
    <!-- favicon -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/bootstrap.min.css')); ?>">

    <!-- slider -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('fontpage/slider/styles.css')); ?>" media="all" />
 



    <!-- fontawesome icon  -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/fontawesome.min.css')); ?>">
    <!-- animate.css  -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/animate.css')); ?>"> 
    <!-- Owl Carousel -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/owl.carousel.min.css')); ?>">
    <!-- flaticon -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/flaticon.css')); ?>">
    <!-- magnific popup -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/magnific-popup.css')); ?>">
    <!-- stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/style.css')); ?>">
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/my.css')); ?>">
 
   
    <link href="<?php echo e(asset('fontpage/newcss/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fontpage/newcss/css/prettyPhoto.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fontpage/newcss/css/price-range.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fontpage/newcss/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('fontpage/newcss/css/responsive.css')); ?>" rel="stylesheet">


   


    

    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/css/mycss.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontpage/css/aso.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('fontpage/assets/css/responsive.css')); ?>">
  
 </head>

<body> 

    <!-- top bar area start -->
    <div class="topbar-bar">
        <div class="container"> 
           <div class="row">
                <div class="col-md-12">
                    <div class="topbar-inner"><!-- topbar inner start -->
                        <div class="topbar-left-content"><!-- topbar left content -->
                        <ul class="topbar-lists">
                            <li class="lists-item">
                                <a href="tel:01218415" style="font-family: arial;" class="lists-link"><i class="fas fa-phone"></i> +8801851708087</a>
                            </li>
                            <li class="lists-item">
                                <a href="mailto:Support@example.com" class="lists-link"><i class="fas fa-envelope"></i> mtfarm@gmail.com</a>
                            </li>
                             
                        </ul>
                        </div><!-- /.topbar left content -->
                        <div class="topbar-right-content">
                            <ul class="social-lists">
                                <li class="social-item">
                                    <a href="#" class="social-link facebook">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li class="social-item">
                                    <a href="#" class="social-link twitter">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                                <li class="social-item">
                                    <a href="#" class="social-link linkedin">
                                        <i class="fab fa-linkedin-in"></i>
                                    </a>
                                </li>
                                <li class="social-item">
                                    <a href="#" class="social-link google-plus">
                                        <i class="fab fa-google-plus-g"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!-- topbar right content end-->
                    </div><!-- topbar inner end -->
                </div>
           </div> <!-- row end -->
        </div><!-- container end -->
    </div>
    <!-- tp bar area end -->

<!-- support bar area start -->
<section data-aos="fade-up" data-aos-duration="1000" class="support-bar-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="support-bar-inner">
                    <div class="left-content-area"><!-- left content area -->
                        <div class="logo">
                            <a href="<?php echo e(route('mitfarm-home')); ?> ">
                                <img data-aos="fade-left"  data-aos-duration="1000" src="<?php echo e(URL('fontpage/assets/img/mitlogo2.png')); ?>" height="60px;" width="90px;" alt="logo images">
                            </a>
                        </div>
                    </div><!-- //. left content area -->
                    <div class="right-content-area"><!-- right content area -->
                        <ul>
                            <li>
                                <div class="single-support-item"><!-- single support item -->
                                    <div class="icon">
                                        <i class="fas fa-headphones"></i>
                                    </div>
                                    <div class="content">
                                        <h4 class="title">24/7 Support</h4>
                                        <span class="details">Awesome Support Center</span>
                                    </div>
                                </div><!-- //. single support item -->
                            </li>
                            <li>
                                <div class="single-support-item"><!-- single support item -->
                                    <div class="icon">
                                        <i class="fas fa-mobile-alt"></i>
                                    </div>
                                    <div class="content pl-40">
                                        <h4 class="title">Private Number</h4>
                                        <span class="details"> +8801851708087</span>
                                    </div>
                                </div><!-- //. single support item -->
                            </li>
                            <li>
                                <div class="single-support-item"><!-- single support item -->
                                    <div class="icon">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                    <div class="content pl-40">
                                        <h4 class="title">Free Calls</h4>
                                        <span class="details">Any Time Call On</span>
                                    </div>
                                </div><!-- //. single support item -->
                            </li>
                        </ul>
                    </div><!-- //. right content area -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- support bar area end -->

    <!-- navbar area start -->
<nav class="navbar navbar-default navbar-area" data-aos="fade-down" data-aos-duration="1000">
    <div class="container">
        <div class="navbar-brand desktop-none">
            <div class="logo">
                <a href="<?php echo e(route('mitfarm-home')); ?> ">
                   <img data-aos="fade-left"  data-aos-duration="1000" src="<?php echo e(URL('fontpage/assets/img/mitlogo2.png')); ?>" height="50px;" width="70px;" alt="logo images">
                </a>
            </div>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#markoz"
                aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="markoz">
            
            <ul class="nav navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('mitfarm-home')); ?> ">Home
                        <span class="sr-only">(current)</span>
                    </a>
                </li>
                
               
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" href="#">pages <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="service.html">Service</a>
                        </li>
                        <li>
                            <a href="data-center.html">Data Center</a>
                        </li>
                        <li>
                            <a href="faq.html">Faq</a>
                        </li>
                    </ul>
                </li>

                 <li class="nav-item search">
                    <a class="nav-link" href="<?php echo e(route('Show-All-Products-mitfarm')); ?> ">All Product</a>
                </li>

                <li class="nav-item dropdown">
             <?php
               $contents = Cart::content();
        
                    
                    if($contents){ ?>

                     <a  class="nav-link dropdown-toggle"   role="button" href="<?php echo e(route('Show-Cart-mitfarm')); ?>"> Cart </a>
                     
                <?php     }  ?>       
                    
                    
                </li>

                <li class="nav-item search">
                <?php 
                  $customer = Session::get('customer_id');
               
          if($customer != Null){ ?>  

                    <a class="nav-link" href="<?php echo e(route('Customer-Profile-mitfarm')); ?> ">Profile</a>
          <?php } ?>
                </li>

                <li class="nav-item search">
                    <a class="nav-link" href="<?php echo e(route('Contick-Page-mitfarm')); ?> ">contact</a>
                </li>


                <li class="nav-item btn-wrapper">
                <?php 
                  $customer = Session::get('customer_id');
               
          if($customer != Null){  ?>    

            <a class="nav-link boxed-btn" href="<?php echo e(route('Logout-Page-mitfarm')); ?>">LogOut</a>
           <?php }else{ ?> 
           <a class="nav-link boxed-btn" href="<?php echo e(route('Login-Page-mitfarm')); ?> ">Lonin</a>
           <?php } ?>
                </li>
            </ul>
            
        </div>
    </div>
</nav>
    <!-- navbar area end -->
<?php echo $__env->yieldContent('body'); ?>
 
 
<!-- footer area start -->
<footer class="footer-area footer-bg">
    <div class="footer-top-area">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-duration="1000">
                    <div class="footer-widget about">
                        <!-- footer widget -->
                        <div class="widget-body">
                            <a href="index-2.html" class="footer-logo">
                                <img src="<?php echo e(asset('fontpage/assets/img/mitlogo2.png')); ?>" height="60px;" width="100px;" alt="footer logo">
                            </a>
                            <p>There are many variations of dummy passages of Lorem able.</p>
                            <ul class="lists">
                                <li>
                                    <a href="#">
                                        <div class="single-about-info">
                                            <!-- single about info-->
                                            <div class="icon">
                                                <i class="far fa-envelope"></i>
                                            </div>
                                            <div class="content">
                                                <span class="details">
                                                    info@example.com</span>
                                            </div>
                                        </div>
                                        <!-- //.single about infor-->
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <div class="single-about-info">
                                            <!-- single about info-->
                                            <div class="icon">
                                                <i class="fas fa-phone"></i>
                                            </div>
                                            <div class="content">
                                                <span class="details">
                                                    +1800 326 3264</span>
                                            </div>
                                        </div>
                                        <!-- //.single about infor-->
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <div class="single-about-info">
                                            <!-- single about info-->
                                            <div class="icon">
                                                <i class="fas fa-map-marker-alt"></i>
                                            </div>
                                            <div class="content">
                                                <span class="details"> 301 The Greenhouse, Custard Factory, London, E2 8DY.</span>
                                            </div>
                                        </div>
                                        <!-- //.single about infor-->
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //.footer widget -->
                </div>
                <div class="col-md-3 col-sm-6" data-aos="fade-left" data-aos-duration="1000">
                    <div class="footer-widget navigation">
                        <!-- footer widget -->
                        <div class="widget-title">
                            <h4 class="title">Products Category</h4>
                        </div>
                        <div class="widget-body">
                            <ul>
                               
              <?php
    $allblog=DB::table('categories')
             ->where('category_status',0)
             ->where('category_type',2)
             ->limit(8)
             ->orderby('category_id','dsce')
             ->get();

    foreach($allblog as $v_blog){    ?>  
                                 <li>                        
                                    <a href="<?php echo e(URL('View-Product-Category-mitfarm',$v_blog->category_id)); ?>">
                                        <i class="fas fa-angle-right"></i><?php echo e($v_blog->category_name); ?></a>
                                </li>
                    <?php } ?>            
                                 
                            </ul>
                        </div>
                    </div>
                    <!-- //.footer widget -->
                </div>
                <div class="col-md-3 col-sm-6"  data-aos="zoom-out" data-aos-duration="1000">
                    <div class="footer-widget navigation">
                        <!-- footer widget -->
                        <div class="widget-title">
                            <h4 class="title">Blog Category</h4>
                        </div>
                        <div class="widget-body">
                            <ul>
                 <?php
    $allblog=DB::table('categories')
             ->where('category_status',0)
             ->where('category_type',1)
             ->limit(8)
             ->orderby('category_id','dsce')
             ->get();

    foreach($allblog as $v_blog){    ?>                 
                                <li>
        <a href="<?php echo e(route('Blog-Category-Page-mitfarm',$v_blog->category_id)); ?>">
            <i class="fas fa-angle-right"></i> <?php echo e($v_blog->category_name); ?></a>
                                </li>
       <?php } ?>                         
                                
                            </ul>
                        </div>
                    </div>
                    <!-- //.footer widget -->
                </div>
                <div class="col-md-3 col-sm-6" data-aos="flip-down" data-aos-duration="1000">
                    <div class="footer-widget navigation">
                        <!-- footer widget -->
                        <div class="widget-title">
                            <h4 class="title">Solutions</h4>
                        </div>
                        <div class="widget-body">
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Legal Information</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Terms of Service</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Acceptable Policy</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Documentation</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-angle-right"></i> Our Partners</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- //.footer widget -->
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-area" >
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="left-cotnent-area">
                        <span class="copyright-text">2018 &copy; All Rights Reserved by <a href="#">MIT Farm</a></span>
                    </div>
                    <div class="right-content-area">
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                            <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->

<div class="back-to-top"> <!-- back to top start -->
    <i class="fas fa-rocket"></i>
</div><!-- back to top end -->
<div class="preloader" id="preloader"><!-- preloader -->
    <div class="preloader-inner">
        <div class="cssload-loader">
            <div class="cssload-inner cssload-one"></div>
            <div class="cssload-inner cssload-two"></div>
            <div class="cssload-inner cssload-three"></div>
        </div>
    </div>
</div><!-- //. preloader -->
    <!-- jquery -->

   

    <script src="<?php echo e(asset('fontpage/assets/js/jquery.js')); ?>"></script>
    <!-- bootstrap -->
    <script src="<?php echo e(asset('fontpage/assets/js/bootstrap.min.js')); ?>"></script>
    <!-- owl carousel -->
    <script src="<?php echo e(asset('fontpage/assets/js/owl.carousel.min.js')); ?>"></script>
    <!-- magnific popup -->
    <script src="<?php echo e(asset('fontpage/assets/js/jquery.magnific-popup.js')); ?>"></script>
    <!-- way poin js-->
    <script src="<?php echo e(asset('fontpage/assets/js/waypoints.min.js')); ?>"></script>
    <!-- wow js-->
    <script src="<?php echo e(asset('fontpage/assets/js/wow.min.js')); ?>"></script>
    <!-- counterup js-->
    <script src="<?php echo e(asset('fontpage/assets/js/jquery.counterup.min.js')); ?>"></script>
    <!-- main -->
    <script src="<?php echo e(asset('fontpage/assets/js/main.js')); ?>"></script>


    <!-- jQuery -->
    <script type="text/javascript" src="<?php echo e(('fontpage/slider/https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js')); ?>"></script>
    <!-- FlexSlider -->
    <script type="text/javascript" src="<?php echo e(('fontpage/slider/js/jquery.flexslider-min.js')); ?>"></script>
    <script type="text/javascript" charset="utf-8">
    var $ = jQuery.noConflict();
    $(window).load(function() {
    $('.flexslider').flexslider({
          animation: "fade"
    });
    
    $(function() {
        $('.show_menu').click(function(){
                $('.menu').fadeIn();
                $('.show_menu').fadeOut();
                $('.hide_menu').fadeIn();
        });
        $('.hide_menu').click(function(){
                $('.menu').fadeOut();
                $('.show_menu').fadeIn();
                $('.hide_menu').fadeOut();
        });
    });
  });
</script>

       

    <script src="<?php echo e(asset('fontpage/newcss/js/price-range.js')); ?>"></script>
    <script src="<?php echo e(asset('fontpage/newcss/js/jquery.scrollUp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('fontpage/newcss/js/jquery.prettyPhoto.js')); ?>"></script>
   


<script src="<?php echo e(asset('fontpage/js/aso.js')); ?>"></script>
<script>
    AOS.init();
  </script>
 
</body>



</html>