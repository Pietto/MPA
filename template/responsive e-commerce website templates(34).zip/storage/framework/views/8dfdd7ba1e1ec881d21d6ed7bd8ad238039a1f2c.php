 

<?php $__env->startSection('body'); ?>

<!-- header area start -->
 
<section style="margin-top:-60px;" class="service-area section-gap" id="service" >

         <div class="our-courses-section">
        <div class="section-title">
            <h3>All Products Category Page</h3>
        </div>
        <div class="container">
            <div class="row">
       <?php
     
    foreach($product as $vproduct){    ?> 

                <div class="col-md-3" data-aos="flip-up" data-aos-duration="2000">
                    <div class="single-course-box">
                        <div class="course-img">
                           <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?> "></a> <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vproduct->product_image)); ?>" alt=""></a>
                            <div class="coures-img-hover">
                                <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?>"><i class="fa fa-link"></i></a>
                            </div>
                        </div>
                      <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?> ">  <span style="font-family: arial;" class="price">$<?php echo e($vproduct->product_price); ?> tk</span></a>
                      <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?> ">   <h3><?php echo e(substr($vproduct->product_title,0,50)); ?> </h3></a>
                    </div>
                </div>
    <?php } ?>            
                 
            </div>
             

    
    </div>
    </div>
</section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>