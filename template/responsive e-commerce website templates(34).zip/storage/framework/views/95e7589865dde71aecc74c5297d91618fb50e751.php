	
 

    <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title><?php echo e($show_product_detels->product_title); ?> || mitfarm</title>
    <meta  name="keywords" content="<?php echo e($show_product_detels->product_tags); ?> ">
    <meta name="viewport" content="<?php echo e($show_product_detels->product_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<br>
<br>
<br>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							 
							 
					 <?php
    $allblog=DB::table('categories')
             ->where('category_status',0)
             ->where('category_type',2)
             ->limit(8)
             ->orderby('category_id','dsce')
             ->get();

    foreach($allblog as $v_blog){    ?>			 
							
							 
								 
							<div data-aos="flip-right" data-aos-duration="1000" class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="<?php echo e(URL('View-Product-Category-mitfarm',$v_blog->category_id)); ?>"><?php echo e($v_blog->category_name); ?></a></h4>
								</div>
							</div>
<?php } ?>							 
						</div><!--/category-products-->
					
					 
						
						 
						
					 
						
					</div>
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img data-aos="zoom-in" data-aos-duration="1000" src="<?php echo e(Illuminate\Support\Facades\Storage::URL($show_product_detels->product_image)); ?> " alt="" />
							 
							</div>
							 

						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
							 
								<h2><?php echo e($show_product_detels->product_title); ?> </h2>
					  
								<form action="<?php echo e(URL('add-to-cart-mitfarm')); ?>" method="post">
									<?php echo e(csrf_field()); ?>

								<span>
									<span>US <?php echo e($show_product_detels->product_price); ?> tk</span>
									<label>Quantity:</label>
									<input type="text" name="qty" value="1" />
									<input type="hidden"  name='product_id' value="<?php echo e($show_product_detels->product_id); ?>" />
									 <br/>
									<button type="submit" class="btn btn-fefault cart">
										<i class="fa fa-shopping-cart"></i>
										Add to cart
									</button>
								</span>
								 </form>
								<p><b>Category:</b> <?php echo e($show_product_detels->category_name); ?></p>
								 
							</div> 
						</div>
					</div><!--/product-details-->
					
					<div class="category-tab shop-details-tab"><!--category-tab-->
						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li  class="active"><a href="#details" data-toggle="tab">Details</a></li>
								 
							</ul>
						</div>
						<div class="tab-content">
							
							
							
							
							<div class="tab-pane fade active in" id="reviews" >
								<div class="col-sm-12">
									 
									<p data-aos="slide-up" data-aos-duration="1000"><?php echo e($show_product_detels->product_detels); ?></p>
								 
									
									
								</div>
							</div>
							
						</div>
					</div><!--/category-tab-->
					
					<div class="recommended_items"><!--recommended_items-->
						<h2 class="title text-center">recommended items</h2>
						
						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								 <div class="item active">	
	 

     <?php
    $allproduct=DB::table('products')
         ->where('product_status',0)
         ->where('product_category_id',$show_product_detels->category_id)
         ->limit(6)
         ->orderby('product_id','dsce')
         ->get();
    foreach($allproduct as $show_product_detels){    ?> 								


		<div class="col-sm-4"  data-aos="flip-up" data-aos-duration="1000">
			<div class="product-image-wrapper">
				<div class="single-products">
	<div class="productinfo text-center">

		<a href="<?php echo e(route('Show-Product-Detels-mitfarm',$show_product_detels->product_id)); ?>">  <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($show_product_detels->product_image)); ?>" height="200px;" width="180px;" alt="" /></a>

		<a href="<?php echo e(route('Show-Product-Detels-mitfarm',$show_product_detels->product_id)); ?>">  <h2><?php echo e($show_product_detels->product_price); ?> tk</h2></a>

		<a href="<?php echo e(route('Show-Product-Detels-mitfarm',$show_product_detels->product_id)); ?>"> <p><?php echo e($show_product_detels->product_title); ?></p></a>

		<a href="<?php echo e(route('Show-Product-Detels-mitfarm',$show_product_detels->product_id)); ?> "><button type="button" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</button></a>

	</div>
				</div>
			</div>
		</div>
<?php } ?>
								 
								</div>
							</div>
							 
							  		
						</div>
					</div><!--/recommended_items-->
					
				</div>
			</div>
		</div>
	</section>

	  <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>