  
<?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>add to cart || <?php echo e($images->website_title); ?> || mitfarm </title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
 <br><br><br>

<div class="cart_main">
	 <div class="container" style="text-align: left;">
			 			
		 <div class="cart-items">
			 <h2>My Shopping Bag </h2>
				
			 <div class="cart-header">
				
	<?php 


   $content = Cart::content();

 

    $i=0;
    $sum =0;
   foreach ($content as $v_content) {
    $i++;
?>			

           
				 <div class="cart-sec">
						<div class="cart-item cyc">
							 <img src="<?php echo e(URL($v_content->options->image)); ?>"/>
						</div>
					   <div class="cart-item-info">
							 <h3><?php echo e($v_content->name); ?>  </h3>
							 <h4 class="font" ><span>Rs.  </span><?php echo e($v_content->price); ?> tk</h4>
							 <form action="<?php echo e(route('Update-Cart-mitfarm',$v_content->rowId)); ?> " method="post">
                              	<?php echo e(csrf_field()); ?>

							 <p class="qty">Qty ::</p>
							 <input  type="number" id="quantity" name="qty" value="<?php echo e($v_content->qty); ?>" class="form-control input-small">

                            <input type="submit" value="Update">
                            </form>
							  <h4 class="font"><span>Total.  </span><?php echo e($v_content->total); ?> tk</h4>

							   <a class="btn btn-danger" onclick="return confirm('ARE YOU SURE TO DELET');" href="<?php echo e(URL('Delete-Cart-mitfarm/'.$v_content->rowId)); ?> "> Delete </a>
					   </div>
					   <div class="clearfix"></div>
											
				  </div>

				  <?php

                 $sum = $v_content->qty+$sum;

                 Session::put('sum',$sum);



				   } ?>	
			 </div>
			 
			 		
		 </div>
		 
		 <div class="cart-total">
			 <a class="continue" href="<?php echo e(route('Show-All-Products-mitfarm')); ?>">Continue to Shoping</a>
			 <div class="price-details">
				 <h3>Price Details</h3>
				 <span>Total</span>
				 <span class="font" class="total"><?php echo e(Cart::subtotal()); ?> </span>
				 <span>Discount</span>
				 <span class="total">--- </span>
				 <span>Delivery Charges</span>
				 <span class="total">---</span>
				 <div class="clearfix"></div>				 
			 </div>	
			 <h4 class="last-price">TOTAL</h4>
			 <span class="font" class="total final"><?php echo e(Cart::total()); ?> tk</span>
			 <div class="clearfix"></div>
            <?php 
                  $customer = Session::get('customer_id');

                  
                ?>    
                 
          <?php if($customer): ?>

			 <a class="order" href="<?php echo e(route('sheping-order-page')); ?>">Order Place</a>
			  <?php else: ?>
			   <a class="order" href="<?php echo e(route('Login-Page-mitfarm')); ?>"> Check Out</a>
			   <?php endif; ?>
			</div>
	 </div>
</div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>