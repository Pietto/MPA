<?php $__env->startSection('body'); ?>




<!-- latest blog area start -->
<section class="latest-blog-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title">
                    <!-- section title -->

                    <h3>GET LATEST BLOG</h3>

                <!-- //. section title -->
            </div>
        </div>
        <div class="row" data-aos="flip-up" data-aos-duration="1000">
 <?php
    $allblog=DB::table('blogs')
             ->where('blog_status',0)
             ->join('categories','blogs.blog_category_id','=', 'categories.category_id')
             ->orderby('blog_id','dsce')
             ->get();

    foreach($allblog as $v_blog){    ?>


            <div class="col-md-4 col-sm-6">
                <div class="single-news-item"><!-- single news item -->
                    <div class="thumb">
                       <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"><img src="<?php echo e(URL::to($v_blog->blog_image)); ?>" alt="news image" width="300px;" height="200px;" ></a>
                    </div>
                    <div class="content">
                        <span class="category"><?php echo e($v_blog->category_name); ?></span>
                        <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"><h4 class="title"><?php echo e($v_blog->blog_title); ?> </h4></a>
                        <span class="date"><?php echo e(date($v_blog->blog_date)); ?></span>
                         <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"> <p><?php echo e(substr($v_blog->blog_detels,0,60)); ?></p></a>
                    </div>
                </div><!-- //.single news item -->
            </div>
<?php } ?>


        </div>

    </div>

</section>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>