 <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>all servece <?php echo e($images->website_title); ?> || mitfarm</title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!-- header area start -->
 
 
<!-- why choose us area start -->
<section class="why-choose-us-area" >
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title"><!-- section title -->
                     
                    <h3>Our Training Courses </h3>
                    
                </div><!-- //. section title -->
            </div>
        </div>
        <div class="row">
             <?php 
    $allservice=DB::table('services')
             ->where('service_type',3)
             ->where('service_status',0)
             ->orderby('service_id','dsce')
             ->get();
    foreach($allservice as $vservice){    ?> 
            <div class="col-md-4 col-sm-6" data-aos="flip-right" data-aos-duration="2000">
                <div class="single-why-us-box"><!-- single why us box -->
                    <div class="icon">
                     <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">  <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vservice->service_image)); ?>" height="160px;" width="180px;" alt=""></a>
                    </div>
                    <div class="content">
                        <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">   <h4 class="title"><?php echo e($vservice->service_title); ?> </h4></a>
                        <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">   <p><?php echo e(substr($vservice->service_detels,0,150)); ?></p></a>
                    </div>
                </div><!-- //.single why us box -->
            </div>
        <?php } ?>    
           
         </div>
          
    </div>
</section>
<!-- why choose us area end -->
<!-- service area start -->
 

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>