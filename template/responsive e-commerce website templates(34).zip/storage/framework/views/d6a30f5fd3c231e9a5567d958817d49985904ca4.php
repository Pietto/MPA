<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Email</title>
</head>
<body>
	<h4> <?php echo e($customer_email); ?> </h4>
	<h4> <?php echo e($customer_name); ?> </h4>
 
	<h4>Verify Code 
	 <?php echo e($code); ?> </h4>
 
</body>
</html>