  

    <?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title>mitfarm Login page <?php echo e($images->website_title); ?> || mitfarm</title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<section id="form"><!--form-->
		<div class="container">
			<div class="row">
<div class="col-sm-4 col-sm-offset-4" class="service-area" data-aos="zoom-out" data-aos-duration="1000">
	  
	<div class="login-form"><!--login form-->
		

		<h2>Login to your account</h2>

		<?php 
         $massage = Session::get('massage');
         
         if($massage){  ?>
          <h4 class="alert alert-danger"> <?php echo $massage; ?>  </h4>
          <?php   Session::put('massage',NULL); } ?>

		<form action="<?php echo e(route('Login-Customer-mitfarm')); ?> " method="post">
			<?php echo e(csrf_field()); ?>

			<input type="email"  name="customer_email" required="" placeholder="Email Address" />
			<input type="Password" name="customer_password" placeholder="Enter Password" required="" />
		
			<button type="submit" class="btn btn-default">Login</button>
		</form>
		<br>
		<br>
			  <!-- <a style="color: red" href="">Forget Password </a>  || -->
			  <a style="color: red" href="<?php echo e(route('New-Customer-Registration-mitfarm')); ?> ">New Customer Registration </a>
	</div><!--/login form-->
</div>
				 

			</div>
		</div>
	</section>

	
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>