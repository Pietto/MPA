<?php $__env->startSection('title'); ?>

         <?php
     $images = DB::table('seo')->where('website_id' ,'1')->first(); ?>
      <title> <?php echo e($images->website_title); ?> </title>
    <meta  name="keywords" content="<?php echo e($images->website_tags); ?> ">
    <meta name="viewport" content="<?php echo e($images->website_detels); ?>">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
 
 <style>
     
     .slider_container{
        padding:0px;
     }
     .flexslider .slides img{
        border:10px #272D39 solid
     }
 </style>
                  
     <div class="slider_container">
        <div class="flexslider">
          <ul class="slides">
            <?php
    $allslider=DB::table('sliders')
             ->where('slider_status',0)
             ->limit(6)
             ->orderby('slider_id','dsce')
             ->get();
    foreach($allslider as $vslider){    ?>

    <li>
    <a href=""><img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vslider->slider_image)); ?>" alt="" title=""/></a>
        <div class="flex-caption">
             <div class="caption_title_line"><h2> </h2><p><?php echo e($vslider->slider_title); ?></p></div>
        </div>
    </li>
    <?php } ?>        
            
        </ul>
      </div>
   </div>
    





 
           
           
       






<!-- header area end -->
<section class="why-choose-us-area" data-aos="zoom-out" data-aos-duration="1000">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title"><!-- section title -->

                    <h3>Our Internation Service </h3>

                </div><!-- //. section title -->
            </div>
        </div>
        <div class="row">
   <?php
    $allservice=DB::table('services')
             ->where('service_type',1)
             ->where('service_status',0)
             ->limit(3)
             ->orderby('service_id','dsce')
             ->get();
    foreach($allservice as $vservice){    ?>
            <div   class="col-md-4 col-sm-6" >
                <div class="single-why-us-box"><!-- single why us box -->
                    <div class="icon">
                      <a href="<?php echo e(route('Service-Detels-Page-mitfarm',$vservice->service_id)); ?> "> <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vservice->service_image)); ?>" height="160px;" width="160px;" alt=""> </a>
                    </div>
                    <div class="content">
                     <a href="<?php echo e(route('Service-Detels-Page-mitfarm',$vservice->service_id)); ?> ">   <h4 class="title"><?php echo e($vservice->service_title); ?> </h4></a> 
                      <a href="<?php echo e(route('Service-Detels-Page-mitfarm',$vservice->service_id)); ?> "> <p><?php echo e(substr($vservice->service_detels,0,150)); ?></p></a> 
                    </div>
                </div><!-- //.single why us box -->
            </div>
 <?php } ?>
        </div>

    </div>
</section>
<section class="service-area" data-aos="zoom-in" data-aos-duration="1000">
    <div class="container">
        <div class="row" data-aos="fade-right" data-aos-duration="5000">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title"><!-- section title -->

                    <h3 data-aos="fade-left" >Our Local Service</h3>

                </div><!-- //. section title -->
            </div>
        </div>
        <div class="row">
       <?php
    $allservice=DB::table('services')
             ->where('service_type',2)
             ->where('service_status',0)
             ->limit(6)
             ->orderby('service_id','dsce')
             ->get();
    foreach($allservice as $vservice){    ?>
            <div class="col-md-4 col-sm-6">
                <div class="single-service-box"><!-- service box -->
                    <div class="icon">
                      <a href="<?php echo e(route('Local-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>"> <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vservice->service_image)); ?>" height="160px;" width="180px;" alt=""></a>
                    </div>
                    <div class="content">
                       <a href="<?php echo e(route('Local-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>"> <h4 class="title"><?php echo e($vservice->service_title); ?></h4></a>
                       <a href="<?php echo e(route('Local-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>"> <p><?php echo e(substr($vservice->service_detels,0,150)); ?></p></a>
                    </div>
                </div><!-- //.single service box -->
            </div>

     <?php } ?>



        </div>

    </div>
</section>
<!-- why choose us area start -->
<section class="why-choose-us-area" data-aos="flip-right" data-aos-duration="2000">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title"><!-- section title -->

                    <h3>Our Training Courses </h3>

                </div><!-- //. section title -->
            </div>
        </div>
        <div class="row">
             <?php
    $allservice=DB::table('services')
             ->where('service_type',3)
             ->where('service_status',0)
             ->limit(6)
             ->orderby('service_id','dsce')
             ->get();
    foreach($allservice as $vservice){    ?>
            <div class="col-md-4 col-sm-6">
                <div class="single-why-us-box"><!-- single why us box -->
                    <div class="icon">
                    <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">  <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vservice->service_image)); ?>" height="160px;" width="180px;" alt=""></a>
                    </div>
                    <div class="content">
                    <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">   <h4 class="title"><?php echo e($vservice->service_title); ?> </h4></a>
                     <a href="<?php echo e(route('Traning-Service-Detels-Page-mitfarm',$vservice->service_id)); ?>">   <p><?php echo e(substr($vservice->service_detels,0,150)); ?></p></a>
                    </div>
                </div><!-- //.single why us box -->
            </div>
        <?php } ?>

         </div>
          <a class="boxed-btn" style="float: right;width: 220px;" href="<?php echo e(route('More-Courses-mitfarm')); ?> ">See More Courses</a>
    </div>
</section>
<!-- why choose us area end -->
<!-- service area start -->

<!-- service area end -->
<section style="margin-top:-60px;" class="service-area section-gap" id="service" data-aos="flip-up" data-aos-duration="2000">

         <div class="our-courses-section">
        <div class="section-title">
            <h3>Our Products</h3>
        </div>
        <div class="container">
            <div class="row">
       <?php
    $allproduct=DB::table('products')
             ->where('product_status',0)
             ->limit(8)
             ->orderby('product_id','dsce')
             ->get();
    foreach($allproduct as $vproduct){    ?> 

                <div class="col-md-3">
                    <div class="single-course-box">
                        <div class="course-img">
                           <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?>"> <img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vproduct->product_image)); ?>" alt=""></a>
                            <div class="coures-img-hover">
                                <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?>"><i class="fa fa-link"></i></a>
                            </div>
                        </div>
                       <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?>">  <span style="font-family: arial;" class="price"><?php echo e($vproduct->product_price); ?> tk</span></a>
                       <a href="<?php echo e(route('Show-Product-Detels-mitfarm',$vproduct->product_id)); ?>">  <h3><?php echo e(substr($vproduct->product_title,0,50)); ?> </h3></a>
                    </div>
                </div>
    <?php } ?>            
                 
            </div>
             

        <a class="boxed-btn" style="float: right;width: 220px;" href="<?php echo e(route('Show-All-Products-mitfarm')); ?> ">See More Shop</a>
    </div>
    </div>
</section>

<!-- latest blog area start -->
<section class="latest-blog-area" data-aos="slide-up" data-aos-duration="1000">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title">
                    <!-- section title -->

                    <h3>GET LATEST BLOG</h3>

                <!-- //. section title -->
            </div>
        </div>
        <div class="row">
 <?php
    $allblog=DB::table('blogs')
             ->where('blog_status',0)
             ->join('categories','blogs.blog_category_id','=', 'categories.category_id')
             ->limit(3)
             ->orderby('blog_id','dsce')
             ->get();

    foreach($allblog as $v_blog){    ?>


            <div class="col-md-4 col-sm-6">
                <div class="single-news-item"><!-- single news item -->
                    <div class="thumb">
                       <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"><img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($v_blog->blog_image)); ?>" alt="news image"></a>
                    </div>
                    <div class="content">
                        <span class="category"><?php echo e($v_blog->category_name); ?></span>
                        <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"><h4 class="title"><?php echo e($v_blog->blog_title); ?> </h4></a>
                        <span class="date"><?php echo e(date($v_blog->blog_date)); ?></span>
                         <a href="<?php echo e(URL::to('Show-Blog-Detels-mitfarm', $v_blog->blog_id)); ?>"> <p><?php echo e(substr($v_blog->blog_detels,0,150)); ?></p></a>
                    </div>
                </div><!-- //.single news item -->
            </div>
<?php } ?>


        </div>
          <a class="boxed-btn" style="float: right;width: 220px;" href="<?php echo e(route('More-Blog')); ?> ">See More Blog</a>
    </div>

</section>
<!-- latest blog area end -->

<!-- megahost area start -->

<section class="megahost-area"  data-aos="fade-right" data-aos-duration="3000">
    <div class="full_bg">
    <div class="left-content-area">
        <div class="img-wrapper">
           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14653.16643388364!2d90.88083732026787!3d23.341447558365857!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3754f52308a2f78d%3A0x4831ae161f5462ff!2sKachua!5e0!3m2!1sen!2sbd!4v1520611688130" width="100%" height="400px;" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-6">
                <div class="right-content-area"><!-- right content area -->

                    <h3 class="title">Contact and Find us</h3>
                    <h4>Contact Info</h4>
                    <p>You can always reach us via following contact details.We will give our best to reach you as possible.</p>
                    <div class="list-wrapper">
                        <ul class="lists">

                        </ul>
                        <ul class="lists">
                            <li class="list-item">
                              <i class="far fa-envelope"></i> mtfarm@gmail.com</li>
                            <li style="font-family: arial;" class="list-item">
                                 <i class="fas fa-phone"></i> +1800 326 3264</li>
                            <li class="list-item">
                                <i class="flaticon-www"></i> www.mitfarm.com </li>

                        </ul>
                    </div>
                </div><!-- //.right content area -->
            </div>
        </div>
    </div>
     </div>
</section>
<!-- megahost area end -->
<section class="latest-blog-area"   data-aos="zoom-in" data-aos-duration="3000">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title">
                    <!-- section title -->

                    <h3>Our Gallery</h3>

                <!-- //. section title -->
            </div>
        </div>
        <div class="row">
   <?php
    $allproduct=DB::table('gelleries')
             ->where('phote_status',0)
             ->limit(6)
             ->orderby('gellery_id','dsce')
             ->get();
    foreach($allproduct as $vproduct){    ?> 

            <div class="col-md-4 col-sm-6" style="margin-bottom: 15px;">
                <div class="single-news-item"><!-- single news item -->
                    <div class="thumb">
                       <a href="blog-details.html"><img src="<?php echo e(Illuminate\Support\Facades\Storage::URL($vproduct->phote_image)); ?>" alt="news image"></a>
                    </div>

                </div><!-- //.single news item -->
            </div>
<?php } ?>
            

            

             

             

            
            <br>

        </div>
          <a class="boxed-btn" style="float: right;width: 220px;margin-top:30px;" href="<?php echo e(route('See-More-Photo-mitfarm')); ?> ">See More Photos</a>
    </div>

</section>
<!-- counterup area start -->
<section class="counterup-area counterup-bg" data-aos="flip-left" data-aos-duration="3000">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="single-counterup-item"><!-- single counter up item -->
                    <div class="icon">
                        <i class="flaticon-www"></i>
                    </div>
                    <div class="content">
                        <div class="counter-wrapper">
                            <span class="count-num">670 </span> Domains
                        </div>
                        <h4 class="title">Registered</h4>
                    </div>
                </div><!-- //.single counter up item -->
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-counterup-item"><!-- single counter up item -->
                    <div class="icon">
                        <i class="flaticon-group"></i>
                    </div>
                    <div class="content">
                        <div class="counter-wrapper">
                            <span class="count-num">980 </span> People
                        </div>
                        <h4 class="title">Happy Clietns</h4>
                    </div>
                </div><!-- //.single counter up item -->
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-counterup-item"><!-- single counter up item -->
                    <div class="icon">
                        <i class="flaticon-cloud"></i>
                    </div>
                    <div class="content">
                        <div class="counter-wrapper">
                            <span class="count-num">250 </span> VPS
                        </div>
                        <h4 class="title">Servers Sold</h4>
                    </div>
                </div><!-- //.single counter up item -->
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-counterup-item"><!-- single counter up item -->
                    <div class="icon">
                        <i class="flaticon-server-5"></i>
                    </div>
                    <div class="content">
                        <div class="counter-wrapper">
                            <span class="count-num">275 </span> Dedicated
                        </div>
                        <h4 class="title">Servers Sold</h4>
                    </div>
                </div><!-- //.single counter up item -->
            </div>
        </div>
    </div>
</section>


<!-- counterup area end -->
 <div class="about-mit-section" data-aos="fade-up" data-aos-duration="3000">
        <div class="container1">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="mit-about-photo">
                        <img style="margin: 30px;" src="<?php echo e(asset('fontpage/assets/img/mitlogo2.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mit-about-content">
                        <h2 class="animated rotateInUpLeft">About <span>MITFarm</span> </h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora quasi, accusantium reiciendis consectetur quidem ex.</p>
                        <div class="learn-btn">
                            <a href="">learn more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<!-- testimonial area start -->
<section class="testimonial-area testimonial-bg" data-aos="flip-up" data-aos-duration="3000">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 text-center">
                <div class="section-title">
                    <!-- section title -->

                    <h3 style="color:#FFF;margin-top:-60px; padding-top:0px; ">OUR CLIENTS & FEEDBACK</h3>

                </div>
                <!-- //. section title -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="testimonial-carousel" id="testimonial-carousel">
         <?php
    $allMember=DB::table('team_mambers')
             ->where('member_status',1)
             ->orderby('member_id','dsce')
             ->get();

    foreach($allMember as $v_member){    ?>            
                    <div class="single-testimonial-carousel"><!-- single testimonial item -->

                        <div style="margin-top: 10px;" class="author-details">
                            <div class="icon">

                         <a href="<?php echo e(route('Show-Team-Mamber-mitfarm',$v_member->member_id)); ?>"> <img  class="thumb22" height="150px;" width="150px;"  src="<?php echo e(Illuminate\Support\Facades\Storage::URL($v_member->member_image)); ?>" alt="mitfarm"></a>

                            </div>

                            <div class="content">
                                <h4 class="title"><?php echo e($v_member->member_name); ?> </h4>
                                
                                <?php if($v_member->member_type==1): ?>
                                <div class="post">  Post : <a href="#">MD </a></div>
                                <?php elseif($v_member->member_type==2): ?>
                                <div class="post"> Post : <a href="#">CEO </a></div>
                                <?php endif; ?>
                                 
                            </div>
                        </div>
                        <br><br><br>
                        <div class="description">
                            <p><?php echo e(substr($v_member->member_detels,0,150)); ?> </p>
                        </div>

                    </div><!-- //. single testimonial item -->

    <?php } ?>          

                     



                </div>
            </div>
        </div>
    </div>
</section>
<!-- testimonial area end -->




                <div style="margin-top:50px;" class="section-title">
                    <!-- section title -->

                    <h3>Our Team Member</h3>

                <!-- //. section title -->
            </div>


 <div data-aos="flip-right" data-aos-duration="3000" class="brand-carousel" id="brand-carousel">

     <?php
    $allMember=DB::table('team_mambers')
            ->orderby('member_id','dsce')
             ->get();

    foreach($allMember as $v_member){    ?> 

        <div class="single-brand-item"><!-- single brand item -->
            <a href="<?php echo e(route('Show-Team-Mamber-mitfarm',$v_member->member_id)); ?> ">
                <img  class="thumb22" height="150px;" width="150px;"  src="<?php echo e(Illuminate\Support\Facades\Storage::URL($v_member->member_image)); ?>" alt="mitfarm">
            </a>
        </div> 
<?php } ?>
        
       
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>